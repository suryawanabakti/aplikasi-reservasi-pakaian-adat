<div class="col-12 col-sm-10 offset-sm-1 col-md-8 offset-md-2 col-lg-8 offset-lg-2 col-xl-8 offset-xl-2">
    <div>
        {{ $logo }}
    </div>
    
    <div>
        {{ $slot }}
    </div>
    
</div>
