<x-app-layout>
    <section class="section">
        <div class="section-header">
            <h1>Dashboard</h1>
            <div class="section-header-breadcrumb">
                <div class="breadcrumb-item">Dashboard</div>
            </div>
        </div>

        <div class="section-body">
            <div class="row">
                <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                    <div class="card card-statistic-1">
                        <div class="card-icon bg-primary">
                            <a href="{{ route('admintoko.products.index') }}"> <i class="fas fa-box"></i></a>
                        </div>
                        <div class="card-wrap">
                            <div class="card-header">
                                <h4>Total Produk</h4>
                            </div>
                            <div class="card-body">
                                {{ DB::table('products')->where('user_id', auth()->id())->count() }}
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                    <div class="card card-statistic-1">
                        <div class="card-icon bg-primary">
                            <a href="{{ route('admintoko.products.index') }}"> <i class="fas fa-exchange-alt"></i></a>
                        </div>
                        <div class="card-wrap">
                            <div class="card-header">
                                <h4>Total Transaksi</h4>
                            </div>
                            <div class="card-body">
                                {{ DB::table('transactions')->where('toko_id', auth()->user()->toko->toko_id ?? 0)->count() }}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">


                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <div class="card-header-action">
                                <button type="button" data-toggle="modal" data-target="#exampleModal"
                                    class="btn btn-primary">Filter</button>
                            </div>

                        </div>
                        <div class="card-body">
                            <div>
                                <canvas id="myChart"></canvas>
                            </div>

                        </div>
                    </div>
                </div>

            </div>

        </div>


    </section>

    <x-slot name="modal">
        <!-- Modal -->
        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Filter</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form action="/dashboard" method="GET" class="mb-2">

                            <div class="form-group">
                                <label for="Dari">Dari</label>
                                <input type="date" class="form-control" name="dari">
                            </div>
                            <div class="form-group">
                                <label for="Sampai">Sampai</label>
                                <input type="date" class="form-control" name="sampai">
                            </div>

                            <button type="submit" class="btn btn-primary">Filter</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
        <script>
            const labels = [
                @foreach ($transactions as $transaction)
                    '{{ $transaction->created_at->format('d M') }}',
                @endforeach
            ];

            const data = {
                labels: labels,
                datasets: [{
                    label: 'Pemasukan (IDR)',
                    backgroundColor: 'rgb(255, 99, 132)',
                    borderColor: 'rgb(255, 99, 132)',
                    data: [
                        @foreach ($transactions as $transaction)
                            '{{ $transaction->total }}',
                        @endforeach
                    ],
                }]
            };

            const config = {
                type: 'line',
                data: data,
                options: {}
            };

            const myChart = new Chart(
                document.getElementById('myChart'),
                config
            );
        </script>



    </x-slot>
</x-app-layout>
