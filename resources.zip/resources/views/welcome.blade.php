<!DOCTYPE html>
<html lang="en">
<!--divinectorweb.com-->

<head>
    <meta charset="UTF-8">
    <meta content="IE=edge" http-equiv="X-UA-Compatible">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title>Adat Kajang</title>
    <!-- All CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css" rel="stylesheet">
    <link href="/css/style.css" rel="stylesheet">
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
        <div class="container">
            <a class="navbar-brand" href="#"><span class="text-warning">ADAT</span>KAJANG</a> <button
                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"
                class="navbar-toggler" data-bs-target="#navbarSupportedContent" data-bs-toggle="collapse"
                type="button"><span class="navbar-toggler-icon"></span></button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" href="#">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#event">Event</a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="#galery">Galery</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#peta">Peta</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#contact">Contact</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="carousel slide" data-bs-ride="carousel" id="carouselExampleIndicators">

        <div class="carousel-inner">
            <div class="carousel-item active">
                <img alt="..." class="d-block w-100" src="https://jadesta.kemenparekraf.go.id/imgpost/27109.jpg">
                <div class="carousel-caption">
                    <h5>WISATA ADAT KAJANG</h5>
                    <p>
                        MASYARAKAT Adat Kajang merupakan salah satu suku yang hidup di Sulawesi Selatan. Mereka tinggal
                        di Kabupaten Bulukumba yang berjarak kurang lebih 200 kilometer dari pusat Kota Makassar.
                    </p>
                    <p><a class="btn btn-warning mt-3" href="/home">RESERVASI</a></p>
                </div>
            </div>
        </div>

    </div><!-- about section starts -->
    <section class="contact section-padding" id="event">
        <div class="container mt-5 mb-5">
            <div class="row">
                <div class="col-md-12">
                    <div class="section-header text-center pb-5">
                        <h2>Event</h2>
                    </div>
                    <div class="section-body ">
                        <div class="row">
                            @foreach ($events as $event)
                                <div class="col-md-4">
                                    <div class="card">
                                        <img class="card-img-top" src="/uploads/image/{{ $event->image }}"
                                            alt="Card image cap">
                                        <div class="card-body">
                                            <h5 class="card-title">{{ $event->name }}</h5>
                                            <p class="card-text">{{ str()->limit($event->description) }}</p>
                                            <small>{{ $event->tanggal_mulai }} s/d {{ $event->tanggal_selesai }}</small>
                                            <br>
                                            <button type="button" class="btn btn-primary btn-sm mt-4"
                                                data-bs-toggle="modal"
                                                data-bs-target="#exampleModal{{ $event->id }}">
                                                Detail
                                            </button>

                                            <!-- Modal -->
                                            <div class="modal fade" id="exampleModal{{ $event->id }}" tabindex="-1"
                                                aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="exampleModalLabel">
                                                                {{ $event->name }}
                                                            </h5>
                                                            <button type="button" class="btn-close"
                                                                data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <b>Deskripsi</b> <br>
                                                            <p>{{ $event->description }}</p>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            @endforeach

                        </div>
                    </div>
                </div>
            </div>
            <div class="row m-0">
                <div class="col-md-12 p-0 pt-4 pb-4">
                    <!--for getting the form download the code from download button-->
                </div>
            </div>
        </div>
    </section>
    <section class="contact section-padding" id="galery">
        <div class="container mt-5 mb-5">
            <div class="row">
                <div class="col-md-12">
                    <div class="section-header text-center pb-5">
                        <h2>Galery</h2>
                    </div>
                    <div class="section-body text-center">
                        <div class="row">
                            <div class="col-md-4">
                                <img title="Balla to kajang"
                                    src="https://img.inews.co.id/media/600/files/networks/2023/01/01/2debd_rumah.jpg"
                                    alt="Balla to kajang" class="img img-fluid">
                            </div>
                            <div class="col-md-4">
                                <img title="Ritual andingingi" alt="Ritual andingingi"
                                    src="https://img.kliknusae.com/uploads/2018/09/ritual.jpg" class="img img-fluid">
                            </div>
                            <div class="col-md-4">
                                <img title="Battasa jera" alt="Battasa jera"
                                    src="https://assets.pikiran-rakyat.com/crop/0x0:0x0/x/photo/2022/04/27/3512813740.jpeg"
                                    class="img img-fluid">
                            </div>
                            <div class="col-md-4 mt-2">
                                <img title="Attunu panroli" alt="Attunu panroli"
                                    src="https://sumeks.disway.id/upload/7dbc2cb4ae1008dfb4a92afb1b4eae8a.jpg"
                                    class="img img-fluid">
                            </div>
                            <div class="col-md-4 mt-2">
                                <img title="Tarian pa'bitte passapu" alt="Tarian pa'bitte passapu"
                                    src="https://media.suara.com/pictures/653x366/2017/11/04/31892-suku-adat-kajang-ammatoa.jpg"
                                    class="img img-fluid">
                            </div>
                            <div class="col-md-4 mt-2">
                                <img title="Sajian songkolo dalam ritual andingingi"
                                    alt="Sajian songkolo dalam ritual andingingi"
                                    src="https://jadesta.kemenparekraf.go.id/imgpost/27109.jpg" class="img img-fluid">
                            </div>

                        </div>
                    </div>
                </div>
            </div>
            <div class="row m-0">
                <div class="col-md-12 p-0 pt-4 pb-4">
                    <!--for getting the form download the code from download button-->
                </div>
            </div>
        </div>
    </section>
    <section class="contact section-padding" id="peta">
        <div class="container mt-5 mb-5">
            <div class="row">
                <div class="col-md-12">
                    <div class="section-header text-center pb-5">
                        <h2>Peta</h2>
                    </div>
                    <div class="section-body text-center">
                        <img src="https://jadesta.kemenparekraf.go.id/imgpost/56419.jpg" alt=""
                            class="img img-fluid">
                    </div>
                </div>
            </div>
            <div class="row m-0">
                <div class="col-md-12 p-0 pt-4 pb-4">
                    <!--for getting the form download the code from download button-->
                </div>
            </div>
        </div>
    </section>
    <!-- Contact starts -->
    <section class="contact section-padding" id="contact">
        <div class="container mt-5 mb-5">
            <div class="row">
                <div class="col-md-12">
                    <div class="section-header text-center pb-5">
                        <h2>Contact Us</h2>

                    </div>
                    <div class="section-body text-center">
                        <iframe
                            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d127120.20030234782!2d120.24733356001249!3d-5.339401959836184!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2dbc1a6e53444d13%3A0x4030bfbcaf77750!2sKec.%20Kajang%2C%20Kabupaten%20Bulukumba%2C%20Sulawesi%20Selatan!5e0!3m2!1sid!2sid!4v1694000503191!5m2!1sid!2sid"
                            width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"
                            referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>
                </div>
            </div>
            <div class="row m-0">
                <div class="col-md-12 p-0 pt-4 pb-4">
                    <!--for getting the form download the code from download button-->
                </div>
            </div>
        </div>
    </section>
    <!-- contact ends -->
    <!-- footer starts -->
    <footer class="bg-dark p-2 text-center">
        <div class="container">
            <p class="text-white">All Right Reserved By @website Name</p>
        </div>
    </footer>
    <!-- footer ends -->

    <!-- All Js -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous">
    </script>
</body>

</html>
